# Color Utils

A Python package to style terminal text using ANSI escape codes. Includes:

- Foreground and background colors
- Bright colors
- Text styles (bold, italic, underline, etc.)
