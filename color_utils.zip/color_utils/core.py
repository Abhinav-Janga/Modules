# Define ANSI escape codes with their corresponding names (colors, styles, background colors, etc.)
# Text Styles
def bold(text):
    return f"\033[1m{text}\033[0m"

def faint(text):
    return f"\033[2m{text}\033[0m"

def italic(text):
    return f"\033[3m{text}\033[0m"

def underline(text):
    return f"\033[4m{text}\033[0m"

def blink(text):
    return f"\033[5m{text}\033[0m"

def reverse(text):
    return f"\033[7m{text}\033[0m"

def hidden(text):
    return f"\033[8m{text}\033[0m"

def strike_through(text):
    return f"\033[9m{text}\033[0m"

def reset(text):
    return f"\033[0m{text}\033[0m"


# Foreground Colors
def black(text):
    return f"\033[30m{text}\033[0m"

def red(text):
    return f"\033[31m{text}\033[0m"

def green(text):
    return f"\033[32m{text}\033[0m"

def yellow(text):
    return f"\033[33m{text}\033[0m"

def blue(text):
    return f"\033[34m{text}\033[0m"

def magenta(text):
    return f"\033[35m{text}\033[0m"

def cyan(text):
    return f"\033[36m{text}\033[0m"

def white(text):
    return f"\033[37m{text}\033[0m"

def gray(text):
    return f"\033[90m{text}\033[0m"

def bright_red(text):
    return f"\033[91m{text}\033[0m"

def bright_green(text):
    return f"\033[92m{text}\033[0m"

def bright_yellow(text):
    return f"\033[93m{text}\033[0m"

def bright_blue(text):
    return f"\033[94m{text}\033[0m"

def bright_magenta(text):
    return f"\033[95m{text}\033[0m"

def bright_cyan(text):
    return f"\033[96m{text}\033[0m"

def bright_white(text):
    return f"\033[97m{text}\033[0m"


# Background Colors
def black_background(text):
    return f"\033[40m{text}\033[0m"

def red_background(text):
    return f"\033[41m{text}\033[0m"

def green_background(text):
    return f"\033[42m{text}\033[0m"

def yellow_background(text):
    return f"\033[43m{text}\033[0m"

def blue_background(text):
    return f"\033[44m{text}\033[0m"

def magenta_background(text):
    return f"\033[45m{text}\033[0m"

def cyan_background(text):
    return f"\033[46m{text}\033[0m"

def white_background(text):
    return f"\033[47m{text}\033[0m"

def gray_background(text):
    return f"\033[48m{text}\033[0m"

def bright_red_background(text):
    return f"\033[101m{text}\033[0m"

def bright_green_background(text):
    return f"\033[102m{text}\033[0m"

def bright_yellow_background(text):
    return f"\033[103m{text}\033[0m"

def bright_blue_background(text):
    return f"\033[104m{text}\033[0m"

def bright_magenta_background(text):
    return f"\033[105m{text}\033[0m"

def bright_cyan_background(text):
    return f"\033[106m{text}\033[0m"

def bright_white_background(text):
    return f"\033[107m{text}\033[0m"


# Extended Foreground Colors
def light_black(text):
    return f"\033[90m{text}\033[0m"

def light_red(text):
    return f"\033[91m{text}\033[0m"

def light_green(text):
    return f"\033[92m{text}\033[0m"

def light_yellow(text):
    return f"\033[93m{text}\033[0m"

def light_blue(text):
    return f"\033[94m{text}\033[0m"

def light_magenta(text):
    return f"\033[95m{text}\033[0m"

def light_cyan(text):
    return f"\033[96m{text}\033[0m"

def light_white(text):
    return f"\033[97m{text}\033[0m"


# Extended Background Colors
def light_black_background(text):
    return f"\033[100m{text}\033[0m"

def light_red_background(text):
    return f"\033[101m{text}\033[0m"

def light_green_background(text):
    return f"\033[102m{text}\033[0m"

def light_yellow_background(text):
    return f"\033[103m{text}\033[0m"

def light_blue_background(text):
    return f"\033[104m{text}\033[0m"

def light_magenta_background(text):
    return f"\033[105m{text}\033[0m"

def light_cyan_background(text):
    return f"\033[106m{text}\033[0m"

def light_white_background(text):
    return f"\033[107m{text}\033[0m"