from setuptools import setup, find_packages

setup(
    name='color_utils',
    version='0.1',
    description='ANSI escape codes for terminal styling: text colors, styles, backgrounds.',
    author='Abhinav janga',
    author_email='Abhinavcoder25@gmail.com',
    packages=find_packages(),
    keywords=['color', 'ansi', 'terminal', 'style', 'text formatting'],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
    python_requires='>=3.6',
)
