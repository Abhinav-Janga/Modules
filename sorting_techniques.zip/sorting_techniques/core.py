class SortingTechniques:
    def bubble_sort(self, arr):
        arr = arr.copy()
        n = len(arr)
        for i in range(n):
            for j in range(0, n - i - 1):
                if arr[j] > arr[j + 1]:
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
        return arr

    def selection_sort(self, arr):
        arr = arr.copy()
        for i in range(len(arr)):
            min_idx = i
            for j in range(i + 1, len(arr)):
                if arr[j] < arr[min_idx]:
                    min_idx = j
            arr[i], arr[min_idx] = arr[min_idx], arr[i]
        return arr

    def insertion_sort(self, arr):
        arr = arr.copy()
        for i in range(1, len(arr)):
            key = arr[i]
            j = i - 1
            while j >= 0 and arr[j] > key:
                arr[j + 1] = arr[j]
                j -= 1
            arr[j + 1] = key
        return arr

    def merge_sort(self, arr):
        def merge(left, right):
            result = []
            i = j = 0
            while i < len(left) and j < len(right):
                if left[i] <= right[j]:
                    result.append(left[i])
                    i += 1
                else:
                    result.append(right[j])
                    j += 1
            return result + left[i:] + right[j:]

        if len(arr) <= 1:
            return arr
        mid = len(arr) // 2
        left = self.merge_sort(arr[:mid])
        right = self.merge_sort(arr[mid:])
        return merge(left, right)

    def quick_sort(self, arr):
        arr = arr.copy()
        if len(arr) <= 1:
            return arr
        pivot = arr[0]
        left = [x for x in arr[1:] if x <= pivot]
        right = [x for x in arr[1:] if x > pivot]
        return self.quick_sort(left) + [pivot] + self.quick_sort(right)

    def heap_sort(self, arr):
        import heapq
        arr = arr.copy()
        heapq.heapify(arr)
        return [heapq.heappop(arr) for _ in range(len(arr))]

    def counting_sort(self, arr):
        arr = arr.copy()
        if not arr:
            return arr
        min_val = min(arr)
        max_val = max(arr)
        range_size = max_val - min_val + 1
        count = [0] * range_size
        output = [0] * len(arr)
        for num in arr:
            count[num - min_val] += 1
        for i in range(1, len(count)):
            count[i] += count[i - 1]
        for num in reversed(arr):
            output[count[num - min_val] - 1] = num
            count[num - min_val] -= 1
        return output

    def radix_sort(self, arr):
        arr = arr.copy()
        if not arr:
            return arr
        max_val = max(arr)
        exp = 1
        while max_val // exp > 0:
            self._counting_sort_exp(arr, exp)
            exp *= 10
        return arr

    def _counting_sort_exp(self, arr, exp):
        n = len(arr)
        output = [0] * n
        count = [0] * 10
        for i in range(n):
            index = (arr[i] // exp) % 10
            count[index] += 1
        for i in range(1, 10):
            count[i] += count[i - 1]
        for i in reversed(range(n)):
            index = (arr[i] // exp) % 10
            output[count[index] - 1] = arr[i]
            count[index] -= 1
        for i in range(n):
            arr[i] = output[i]

    def bucket_sort(self, arr):
        arr = arr.copy()
        if not arr:
            return arr
        n = len(arr)
        buckets = [[] for _ in range(n)]
        for num in arr:
            index = int(num * n)
            buckets[index].append(num)
        for i in range(n):
            buckets[i] = sorted(buckets[i])
        return [item for sublist in buckets for item in sublist]

    def tim_sort(self, arr):
        return sorted(arr)
