from .core import SortingTechniques
