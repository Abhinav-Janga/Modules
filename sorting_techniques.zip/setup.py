from setuptools import setup, find_packages

setup(
    name='sorting_techniques',
    version='0.1',
    description='A collection of sorting algorithms implemented in Python.',
    author='Abhinav janga',
    author_email='Abhinavcoder25@gmail.com',
    packages=find_packages(),
    keywords=['sorting', 'algorithms', 'python', 'data structures'],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
    python_requires='>=3.6',
)
