# Sorting Techniques

A Python package with implementations of common sorting algorithms like:
- Bubble Sort
- Merge Sort
- Quick Sort
- Heap Sort
- Radix Sort
- Bucket Sort
- and more...